package com.covid.service;

import com.covid.model.Herbal;
import com.covid.repository.HerbalRepository;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class HerbalService {
    @Autowired
    private HerbalRepository herbalRepository;

    public Herbal getById(Integer id){
        return herbalRepository.findById(id).get();
    }
}
