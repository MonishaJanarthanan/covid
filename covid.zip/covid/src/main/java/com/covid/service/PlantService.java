package com.covid.service;

import com.covid.model.Plant;
import com.covid.repository.PlantRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PlantService {

    @Autowired
    private PlantRepository plantRepository;

    public Plant getById(Integer id){
        return plantRepository.findById(id).get();
    }

    public List<Plant> getByName(String compoundName){
        return plantRepository.findByCompoundName(compoundName);
    }

}
