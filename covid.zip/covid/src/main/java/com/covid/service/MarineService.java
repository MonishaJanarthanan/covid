package com.covid.service;

import com.covid.model.Marine;
import com.covid.repository.MarineRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class MarineService {

    @Autowired
    private MarineRepository marineRepository;

    public Marine getById(Integer id){
        return marineRepository.findById(id).get();

    }
}
