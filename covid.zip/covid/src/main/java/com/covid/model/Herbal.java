package com.covid.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "HERBAL")
public class Herbal {

    @Id
    @Column(name = "PUBCHEM_ID")
    private int id;
    @Column(name = "COMPOUND_NAME")
    private String compoundName;
    @Column(name = "2D_STRUCTURE")
    private String twoDStructure;
    @Column(name = "3D_STRUCTURE")
    private String threeDStructure;
    @Column(name = "MOLECULAR_FORMULA")
    private String molecularFormula;
    @Column(name = "CANONICAL_SMILIES")
    private String canonicalSmilies;
    @Column(name = "GPCR_LIGAND")
    private String gpcrLigand;
    @Column(name = "ION_CHANNEL_MODULATOR")
    private Float ionChannelModulator;
    @Column(name = "KINASE_MODULATOR")
    private String kinaseModulator;
    @Column(name = "NUCLEAR_RECEPTOR_LIGAND")
    private String nuclearReceptorLigand;
    @Column(name = "PROTEASE_INHIBITOR")
    private String proteaseInhibitor;
    @Column(name = "ENZYME_INHIBITOR")
    private String enzymeInhibitor;


}
