package com.covid.repository;

import com.covid.model.Herbal;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface HerbalRepository extends JpaRepository<Herbal,Integer> {

}
