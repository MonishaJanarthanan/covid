package com.covid.controller;

import com.covid.model.Herbal;
import com.covid.model.Plant;
import com.covid.service.PlantService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.NoSuchElementException;

@RestController
@RequestMapping("/plant")
public class PlantController {
    @Autowired
    private PlantService plantService;

    @GetMapping("/{id}")
    public ResponseEntity<Plant> get(@PathVariable Integer id) {
        try {
            Plant plant = plantService.getById(id);
            return new ResponseEntity<Plant>(plant, HttpStatus.OK);
        } catch (NoSuchElementException e) {
            return new ResponseEntity<Plant>(HttpStatus.NOT_FOUND);
        }
    }

   @GetMapping("plants/{compoundName}")
    public  List<Plant> getByName(@PathVariable("compoundName") String compoundName){
        return plantService.getByName(compoundName);
   }
}
