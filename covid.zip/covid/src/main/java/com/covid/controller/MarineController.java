package com.covid.controller;

import com.covid.model.Marine;
import com.covid.model.Plant;
import com.covid.service.MarineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.NoSuchElementException;

@RestController
@RequestMapping("/marine")
public class MarineController {

    @Autowired
    private MarineService marineService;

    @GetMapping("/{id}")
    public ResponseEntity<Marine> get(@PathVariable Integer id) {
        try {
            Marine marine = marineService.getById(id);
            return new ResponseEntity<Marine>(marine, HttpStatus.OK);
        } catch (NoSuchElementException e) {
            return new ResponseEntity<Marine>(HttpStatus.NOT_FOUND);
        }
    }
}
