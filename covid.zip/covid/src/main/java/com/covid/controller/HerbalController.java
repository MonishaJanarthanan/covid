package com.covid.controller;

import com.covid.model.Herbal;
import com.covid.service.HerbalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.NoSuchElementException;

@RequestMapping("/herbal")
@RestController
public class HerbalController {

    @Autowired
    private HerbalService herbalService;

    @GetMapping("/{id}")
    public ResponseEntity<Herbal> get(@PathVariable Integer id) {
        try {
            Herbal herbal = herbalService.getById(id);
            return new ResponseEntity<Herbal>(herbal, HttpStatus.OK);
        } catch (NoSuchElementException e) {
            return new ResponseEntity<Herbal>(HttpStatus.NOT_FOUND);
        }
    }
}